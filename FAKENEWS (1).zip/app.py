from flask import Flask, redirect, url_for, render_template, request, redirect, jsonify
import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score, confusion_matrix
from werkzeug.utils import secure_filename
import pytesseract
from PIL import Image
import pickle

pytesseract.pytesseract.tesseract_cmd = (
    r"C:\Users\KLH-1-23\AppData\Local\Programs\Tesseract-OCR\tesseract.exe"
)


tfvect = TfidfVectorizer(stop_words="english", max_df=0.7)
loaded_model = pickle.load(open("model.pkl", "rb"))
dataframe = pd.read_csv("media/fake_or_real_news.csv")
x = dataframe["text"]
y = dataframe["label"]
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=0)

tfid_x_train = tfvect.fit_transform(x_train)
tfid_x_test = tfvect.transform(x_test)
y_pred = loaded_model.predict(tfid_x_test)
# accuracy = accuracy_score(y_test, y_pred)
# print("Model Accuracy:", accuracy)


def fake_news_det(news):
    # tfid_x_train = tfvect.fit_transform(x_train)
    # tfid_x_test = tfvect.transform(x_test)
    input_data = [news]
    vectorized_input_data = tfvect.transform(input_data)
    prediction = loaded_model.predict(vectorized_input_data)
    return prediction


UPLOAD_FOLDER = os.path.join("static", "images")
app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.secret_key = "This is your secret key to utilize session in Flask"


@app.route("/")
def main():
    return render_template("main.html")


@app.route("/passhome")
def passhome():
    return render_template("home.html")


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/contact")
def contact():
    return render_template("contact.html")


@app.route("/upload", methods=["GET", "POST"])
def upload():
    if request.method == "POST":
        if "image" not in request.files:
            return jsonify({"error": "No image file found."}), 400

        image_file = request.files["image"]

        if image_file.filename == "":
            return jsonify({"error": "No selected image file."}), 400

        filename = secure_filename(image_file.filename)
        image_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        image_file.save(image_path)

        image = Image.open(image_path)
        text = pytesseract.image_to_string(image)
        # Remove line breaks and replace with spaces
        pred = fake_news_det(text)
        print(pred[0])
        return render_template(
            "result1.html", image_path=image_path, prediction=pred[0]
        )

    return render_template("upload.html")


@app.route("/register", methods=["POST", "GET"])
def register():

    if request.method == "POST":
        name = request.form["firstname"]
        lname = request.form["lastname"]
        uemail = request.form["email"]
        Password = request.form["password"]
        print(name, lname, uemail, Password)
        import sqlite3

        con = sqlite3.connect("test1.db")
        cur = con.cursor()
        a = f"select email from emp where email='{uemail}'"
        cur.execute(a)
        result = cur.fetchone()
        if result != None:
            return "email alredy registered"
        else:
            # a="create table emp(name varchar(100),lastname varchar(100),email varchar(100),password varchar(100))"
            cur.execute(
                "INSERT INTO emp('name', 'lastname', 'email', 'password') VALUES (?,?,?,?)",
                (name, lname, uemail, Password),
            )
            con.commit()
            con.close()
            return redirect(url_for("passhome"))

    return render_template("register.html")


@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        uemail = request.form["email"]
        upassword = request.form["password"]
        print(uemail, upassword)
        import sqlite3

        con = sqlite3.connect("test1.db")
        cur = con.cursor()
        a = f"select * from emp where email='{uemail}' and password ='{upassword}'"
        cur.execute(a)
        result = cur.fetchone()
        print("database", result)
        if result == None:
            return "enter valid details"
        else:
            return redirect(url_for("passhome"))
    return render_template("login.html")


@app.route("/logout")
def logout():
    return redirect(url_for("main"))


@app.route("/home", methods=["POST", "GET"])
def home():
    return render_template("home.html")


@app.route("/predict", methods=["POST"])
def predict():
    # print("hi")

    if request.method == "POST":
        comment = request.form["comment"]
        pred = fake_news_det(comment)

        # features_test = cv.transform(messages_test)
        return render_template("result.html", prediction=pred[0])
    return render_template("home.html")


if __name__ == "__main__":
    # DEBUG is SET to TRUE. CHANGE FOR PROD
    app.run(debug=True)
